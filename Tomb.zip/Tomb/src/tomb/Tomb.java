package tomb;

public class Tomb {

    public static void main(String[] args) {
        double atlagido = 2.3;
        //System.out.printf("%d. ido: %.2f\n",1, atlagido);
        double[] korido = {atlagido, 3.45, 2.05, 3.3};
        //korido = new double[5];
        //korido[0]=2.30;
        //korido[1]=3.40;
        //korido[0]=2.45;
        //korido[0]=5.32;
        //korido[0]=2.34;
        for (int i = 0; i < korido.length; i++) {
            System.out.printf("%d. idő: %.2f\n", i + 1, korido[i]);
        }
        String[] tombgy = {"Pál", "Péter", "Ed", "Arglebarg"};
        System.out.println(tombgy[0]);
        System.out.println(tombgy[tombgy.length - 1]);
        int legrovidebb = 0;
        String minszo = tombgy[0];
        for (int i = 0; i < tombgy.length; i++) {
            if (tombgy[i].length() < minszo.length()) {
                minszo = tombgy[i];
                legrovidebb = i;
            }
        }
        int leghosszabb = 0;
        System.out.println(tombgy[legrovidebb]);

        for (int i = 0; i < tombgy.length; i++) {
            if (tombgy[leghosszabb].length() < tombgy[i].length()) {
                leghosszabb = i;
            }
        }
        for (int i = 0; i < tombgy.length; i++) 
        {
            if (tombgy[i].charAt(0) != 'P' && tombgy[i].charAt(0) != 'p' ) {   
               System.out.println(tombgy[i]);
            }
        }
    }
}
