
package javaapplication22;

import java.util.Arrays;
import java.util.Random;

public class JavaApplication22 {

    public static void main(String[] args) {
        int[] sorozat = getRandomArray(10);
        System.out.println("A tömb elemei: " + Arrays.toString(sorozat));
        assert rendezett(sorozat) : "Nem rendezett tömb!";

    }

    private static int[] getRandomArray(int size) {
        int[] tomb = new int[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            tomb[i] = random.nextInt(100);
        }
        return tomb;
    }

    private static boolean rendezett(int[] tomb) {
        for (int i = 0; i < tomb.length - 1; i++) {
            if (tomb[i] > tomb[i + 1]) {
                return false;
            }
        }
        return true;
    }
}


